/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg23mdavidharangozoliska_hracojestenemanazev;

import java.util.Scanner;

import java.util.Random;

/**
 *
 * @author matyh
 */
public class DavidHarangozoLiska23M_hracojestenemanazev {

    static int RIZZ = 0;

    static int RIZZLVL = 1;

    static double nasobic = 1.2;

    /**
     * @param args the command line arguments
     */
    public static void rizz() {

        if (RIZZ < 10) {

            RIZZLVL = 1;
            nasobic = 1.2;
        } else if (RIZZ < 20) {

            RIZZLVL = 2;
            nasobic = 1.4;
        } else if (RIZZ < 30) {

            RIZZLVL = 3;
            nasobic = 1.6;
        } else if (RIZZ < 40) {

            RIZZLVL = 4;
            nasobic = 1.8;
        } else {

            RIZZLVL = 5;
            nasobic = 2;
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here

        Scanner vstup = new Scanner(System.in);

        Random random = new Random();

        int lokace = 0;

        boolean[] navstiveno = new boolean[20];

        boolean ruki = false;

        boolean nabidka = false;

        boolean voda = false;

        boolean cina = false;

        int kruh = 0;

        System.out.println("Napis sve jmeno:");

        vstup.nextLine();

        System.out.println("Ahoj, hezke jmeno, ale vubec me nezajima Moggere.\n Pro zapnuti hry napis SIGMA.");

        String start = vstup.nextLine();

        while (!start.equalsIgnoreCase("SIGMA")) {

            System.out.println("L rizz, napsal si to spatne");

            System.out.println("Pro zapnuti napis SIGMA.");

            start = vstup.nextLine();

        }

        System.out.println("Vitej Moggere objevil si se v lokaci mystickeho stromu a neco ti yappuje:\n\"Ahoj Moggere, vitej v Ohiu. Slysel jsem, ze mas velky crush na Livvy Dunne,");
        System.out.println("mam doboru zpravu, je uveznena ve skibidi kralovstvi a chrani ji obavany sigma,\ntakze jestli ji chces pullnout, tak budes muset nagainit RIZZ.");
        System.out.println("Pred tim nez se vydas na svou cestu, tak ti dam tuhle tabulku RIZZLEVELU, mapu a slovnik.\"");

        vstup.nextLine();

        System.out.println("Dostal si:\n*tabulka RIZZLEVELU*\n*mapa*\n*slovnik*");

        vstup.nextLine();

        System.out.println("Podival si se do tabulky a vidis:\nRIZZLVL.1\n 1-10r\nRIZZLVL.2\n 11-20r\nRIZZLVL.3\n 21-30r\nRIZZLVL.4\n 31-40r\nRIZZLVL.5\n 41-50r");

        vstup.nextLine();

        while (true) {

            switch (lokace) {
                case 0: //0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000

                    if (navstiveno[lokace]) {

                        System.out.println("Jsi zpatky u Mystickeho stromu.");

                    }

                    navstiveno[lokace] = true;

                    System.out.println("Podival si se do mapy a vidis, ze mas momentalne jen dve moznosti:\nJit do restaurace Masokoule Martina[1]\nJit do uzenarstvi Honzy Slaniny[2]");

                    while (true) {

                        try {

                            int lokace0 = vstup.nextInt();

                            if (lokace0 == 1 || lokace0 == 2) {

                                lokace = lokace0;

                                break;

                            } else {

                                System.out.println("Nepodvadej!!!\nNapis [1] nebo [2].");

                            }

                        } catch (java.util.InputMismatchException e) {

                            System.out.println("Napis [1] nebo [2].");

                            vstup.nextLine();

                        }

                    }

                    break;
                case 1: //1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111

                    if (navstiveno[lokace]) {

                        System.out.println("V restauraci Masokoule Martina si sve moznosti uz vypotreboval.\nPodival si se do mapy a vidis, ze mas momentalne tri moznosti:\nJit ke mystickemu stromu[0]\nJit se podivat do parku[3]\nJit poznat sve chakry[4]");

                        while (true) {

                            try {

                                int lokace1 = vstup.nextInt();

                                if (lokace1 == 0 || lokace1 == 3 || lokace1 == 4) {

                                    lokace = lokace1;

                                    break;

                                } else {

                                    System.out.println("Napis [0], [3] nebo [4].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [0], [3] nebo [4].");

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Vchazis do restaurace Masokoule Martina. Restaurace ma dobry vibe a v radiu hraje novy banger Thick of it od KSI.");
                        System.out.println("U pultu sedi znamy influencer a looksmaxxer ruki bazuki, ktery na tebe hazi divny pohled. Sefkuchar Masokoule Martin zrovna nekomu vola mezitim co se mu vzadu v kuchyni smazi dalsi varka masovych kouli.");
                        System.out.println("Co udelas?\nJit nastolit dominanci nad Masokouli Martinem a tim pravdepodobne ziskat RIZZ[1]\nJit si promluvit s ruki bazuki[2]\nZustat ve vchodu a tvarit se mysteriozne[3]");

                        while (true) {

                            try {

                                int volba1 = vstup.nextInt();

                                if (volba1 == 1 || volba1 == 2 || volba1 == 3) {

                                    if (volba1 == 1) {

                                        rizz();

                                        System.out.println("Vyzval si Masokouli Martina na MOG BATTLE.");

                                        int aura1 = 100;
                                        int aura2 = 200;

                                        rizz();

                                        while (aura1 > 0 && aura2 > 0) {

                                            int damage1 = (int) (random.nextInt(41) * nasobic);

                                            aura2 -= damage1;

                                            System.out.println("Tvuj pohled zasahl Masokouli Martina za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nMasokoule Martin aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura2 <= 0) {

                                                System.out.println("V MOG BATTLU si vyhral");

                                                System.out.println("Prave si ziskal 5 RIZZU.");

                                                RIZZ += 5;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit ke mystickemu stromu[0]\nJit se podivat do parku[3]\nJit poznat sve chakry[4]");

                                                while (true) {

                                                    try {

                                                        int lokace1 = vstup.nextInt();

                                                        if (lokace1 == 0 || lokace1 == 3 || lokace1 == 4) {

                                                            lokace = lokace1;

                                                            break;

                                                        } else {

                                                            System.out.println("Napis [0], [3] nebo [4].");

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        System.out.println("Napis [0], [3] nebo [4].");

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                            int damage2 = random.nextInt(11);

                                            aura1 -= damage2;

                                            System.out.println("Pohled Masokoule Martina te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nMasokoule Martin aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura1 <= 0) {

                                                System.out.println("V MOG BATTLU si prohral.");

                                                System.out.println("Prave si prisel o 2 RIZZU.");

                                                RIZZ -= 2;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit ke mystickemu stromu[0]\nJit se podivat do parku[3]\nJit poznat sve chakry[4]");

                                                while (true) {

                                                    try {

                                                        int lokace1 = vstup.nextInt();

                                                        if (lokace1 == 0 || lokace1 == 3 || lokace1 == 4) {

                                                            lokace = lokace1;

                                                            break;

                                                        } else {

                                                            System.out.println("Napis [0], [3] nebo [4].");

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        System.out.println("Napis [0], [3] nebo [4].");

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                        }

                                    } else if (volba1 == 2) {

                                        System.out.println("Ruki Bazuki te ponizuje a odhani pryc z restaurace.\nZtracis 2 RIZZY!");

                                        RIZZ -= 2;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit ke mystickemu stromu[0]\nJit se podivat do parku[3]\nJit poznat sve chakry[4]");

                                        while (true) {

                                            try {

                                                int lokace1 = vstup.nextInt();

                                                if (lokace1 == 0 || lokace1 == 3 || lokace1 == 4) {

                                                    lokace = lokace1;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [0], [3] nebo [4].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [0], [3] nebo [4].");

                                                vstup.nextLine();

                                            }

                                        }

                                        break;

                                    } else {

                                        System.out.println("Rukimu Bazuki se zalibi tvuj mysteriozni pohled a poziva te si k tobe prisednout. Po par hodinach povidani a nekolik desitek masovych kouli ti nabizi pomoc na tve ceste");
                                        System.out.println("Prijimas jeho nabidku?\nAno[1]\nAno[2]");

                                        vstup.nextLine();

                                        System.out.println("Skvela volba! Od ted do te doby co s tebou bude Ruki Bazuki mas +10 RIZZU.");

                                        ruki = true;

                                        RIZZ += 10;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit ke mystickemu stromu[0]\nJit se podivat do parku[3]\nJit poznat sve chakry[4]");

                                        while (true) {

                                            try {

                                                int lokace1 = vstup.nextInt();

                                                if (lokace1 == 0 || lokace1 == 3 || lokace1 == 4) {

                                                    lokace = lokace1;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [0], [3] nebo [4].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [0], [3] nebo [4].");

                                                vstup.nextLine();

                                            }

                                        }

                                        break;

                                    }

                                    break;
                                } else {

                                    System.out.println("Nepodvadej!!!\nNapis [1], [2] nebo [3].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1], [2] nebo [3].");

                                vstup.nextLine();

                            }
                        }

                    }

                    break;
                case 2: //22222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222

                    if (navstiveno[lokace]) {

                        System.out.println("V uzenartstvi Honzy Slaniny si sve moznosti uz vypotreboval.\nPodival si se do mapy a vidis, ze mas momentalne ctyri moznosti:\nJit ke mystickemu stromu[0]\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do cinske ctvrti[5]");

                        while (true) {

                            try {

                                int lokace2 = vstup.nextInt();

                                if (lokace2 == 0 || lokace2 == 3 || lokace2 == 4 || lokace2 == 5) {

                                    lokace = lokace2;

                                    break;

                                } else {

                                    System.out.println("Napis [0], [3], [4] nebo [5].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [0], [3], [4] nebo [5].");

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Vchazis do uzenarstvi Honzy Slaniny, ktery zrovna kraji na platky novy salam. Kdyz si te to prase Honza Slanina vsimne hned pozna, ze nejsi vasnivy fanousek uzenin, a proto te svym cenichem vyzyva na MOG BATTLE.");
                        System.out.println("Co udelas?\nVyzvat prijmu[1]\nZbabele utect a pravdepodobne ztratit nejaky RIZZ[2]");

                        while (true) {

                            try {

                                int volba2 = vstup.nextInt();

                                if (volba2 == 1 || volba2 == 2) {

                                    if (volba2 == 1) {

                                        rizz();

                                        System.out.println("Vyzval si prijmu Honzy Slaniny na MOG BATTLE.");

                                        int aura1 = 100;
                                        int aura2 = 150;

                                        rizz();

                                        while (aura1 > 0 && aura2 > 0) {

                                            int damage2 = random.nextInt(21);

                                            aura1 -= damage2;

                                            System.out.println("Pohled Honzy Slaniny te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nHonza Slanina aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura1 <= 0) {

                                                System.out.println("V MOG BATTLU si prohral");

                                                System.out.println("Prave si ztratil 2 RIZZY.");

                                                RIZZ -= 2;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit ke mystickemu stromu[0]\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do cinske ctvrti[5]");

                                                while (true) {

                                                    try {

                                                        int lokace2 = vstup.nextInt();

                                                        if (lokace2 == 0 || lokace2 == 3 || lokace2 == 4 || lokace2 == 5) {

                                                            lokace = lokace2;

                                                            break;

                                                        } else {

                                                            System.out.println("Napis [0], [3], [4] nebo [5].");

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        System.out.println("Napis [0], [3], [4] nebo [5].");

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                            int damage1 = (int) (random.nextInt(41) * nasobic);

                                            aura2 -= damage1;

                                            System.out.println("Tvuj pohled zasahl Honzu Slaninu za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nHonza Slanina aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura2 <= 0) {

                                                System.out.println("V MOG BATTLU si vyhral.");

                                                System.out.println("Prave si ziskal 5 RIZZU.");

                                                RIZZ += 5;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit ke mystickemu stromu[0]\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do cinske ctvrti[5]");

                                                while (true) {

                                                    try {

                                                        int lokace2 = vstup.nextInt();

                                                        if (lokace2 == 0 || lokace2 == 3 || lokace2 == 4 || lokace2 == 5) {

                                                            lokace = lokace2;

                                                            break;

                                                        } else {

                                                            System.out.println("Napis [0], [3], [4] nebo [5].");

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        System.out.println("Napis [0], [3], [4] nebo [5].");

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                        }

                                    } else {

                                        System.out.println("Utikas pred MOG BATTLEM s Honzou Slaninou.\nZtracis 4 RIZZY!");

                                        RIZZ -= 4;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit ke mystickemu stromu[0]\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do cinske ctvrti[5]");

                                        while (true) {

                                            try {

                                                int lokace2 = vstup.nextInt();

                                                if (lokace2 == 0 || lokace2 == 3 || lokace2 == 4 || lokace2 == 5) {

                                                    lokace = lokace2;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [0], [3], [4] nebo [5].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [0], [3], [4] nebo [5].");

                                                vstup.nextLine();

                                            }

                                        }

                                        break;

                                    }

                                    break;

                                } else {

                                    System.out.println("Nepodvadej!!!\nNapis [1], [2] nebo [3].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }
                        }

                    }

                    break;

                case 3: //333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333

                    if (navstiveno[lokace]) {

                        System.out.println("V parku si sve moznosti uz vypotreboval.\nPodival si se do mapy a vidis, ze mas momentalne ctyri moznosti:\nJit do restaurace Masokoule Martina[1]\nJit do uzenarstvi Honzy Slaniny[2]\nJit se podivat na namesti[6]\nJit se podivat do metra[7]");

                        while (true) {

                            try {

                                int lokace3 = vstup.nextInt();

                                if (lokace3 == 1 || lokace3 == 2 || lokace3 == 6 || lokace3 == 7) {

                                    lokace = lokace3;

                                    break;

                                } else {

                                    System.out.println("Napis [1], [2], [6] nebo [7].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1], [2], [6] nebo [7].");

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Prichazis do parku a vidis pohodovyho typka si hledet svyho.\nCo udelas?\nJen stat a tvarit se mysteriozne[1]\nJit si pokecat s pohodovym typkem[2]\nVyzvat pohodoveho typka na MOG BATTLE[3]");

                        while (true) {

                            try {

                                int volba3 = vstup.nextInt();

                                if (volba3 == 1 || volba3 == 2 || volba3 == 3) {

                                    if (volba3 == 1) {

                                        System.out.println("Pohodovymu typkovi je tvuj mysteriozni pohled uplne jedno a mizi. Tvuj RIZZ se nemeni.");

                                        System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do restaurace Masokoule Martina[1]\nJit do uzenarstvi Honzy Slaniny[2]\nJit se podivat na namesti[6]\nJit se podivat do metra[7]");

                                        while (true) {

                                            try {

                                                int lokace3 = vstup.nextInt();

                                                if (lokace3 == 1 || lokace3 == 2 || lokace3 == 6 || lokace3 == 7) {

                                                    lokace = lokace3;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [1], [2], [6] nebo [7].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [1], [2], [6] nebo [7].");

                                                vstup.nextLine();

                                            }

                                        }

                                        break;

                                    } else if (volba3 == 2) {

                                        System.out.println("Po chvilce povidani si s pohodovym typkem ti nabizi, ze se tebou necha porazit v MOG BATTLE, aby si ziskal RIZZ co potrebujes k ziskani LIVVY DUNNE.");
                                        System.out.println("Pohodovy typek se nechava porazit v MOG BATTLU a ty ziskavas 4 RIZZY.");

                                        RIZZ += 4;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do restaurace Masokoule Martina[1]\nJit do uzenarstvi Honzy Slaniny[2]\nJit se podivat na namesti[6]\nJit se podivat do metra[7]");

                                        while (true) {

                                            try {

                                                int lokace3 = vstup.nextInt();

                                                if (lokace3 == 1 || lokace3 == 2 || lokace3 == 6 || lokace3 == 7) {

                                                    lokace = lokace3;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [1], [2], [6] nebo [7].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [1], [2], [6] nebo [7].");

                                                vstup.nextLine();

                                            }

                                        }

                                        break;

                                    } else {

                                        System.out.println("Pred tim nez stihnes zautocit pohodovy typek mizi a ty ztracis 4 RIZZY.");

                                        RIZZ -= 4;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do restaurace Masokoule Martina[1]\nJit do uzenarstvi Honzy Slaniny[2]\nJit se podivat na namesti[6]\nJit se podivat do metra[7]");

                                        while (true) {

                                            try {

                                                int lokace3 = vstup.nextInt();

                                                if (lokace3 == 1 || lokace3 == 2 || lokace3 == 6 || lokace3 == 7) {

                                                    lokace = lokace3;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [1], [2], [6] nebo [7].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [1], [2], [6] nebo [7].");

                                                vstup.nextLine();

                                            }

                                        }
                                    }

                                    break;

                                } else {

                                    System.out.println("Nepodvadej!!!\nNapis [1], [2] nebo [3].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }

                        }

                    }

                    break;

                case 4: //444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444

                    if (navstiveno[lokace]) {

                        System.out.println("V opustene budove si sve se stojatou vodou si sve moznosti uz vypotreboval.");
                        System.out.println("Podival si se do mapy a vidis, ze mas momentalne pet moznosti:\nJit do restaurace Masokoule Martina[1]\nJit do uzenarstvi Honzy Slaniny[2]\nJit se podivat na namesti[6]\nJit se podivat do metra[7]\nJit k barberovi[8]");

                        while (true) {

                            try {

                                int lokace4 = vstup.nextInt();

                                if (lokace4 == 1 || lokace4 == 2 || lokace4 == 6 || lokace4 == 7 || lokace4 == 8) {

                                    lokace = lokace4;

                                    break;

                                } else {

                                    System.out.println("Napis [1], [2], [6], [7] nebo [8].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1], [2], [6], [7] nebo [8].");

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Prichazis do opustene budovy a prozkoumavas sklep. V ceste hloubeji do sklepa te, ale zastavi stojata voda, ktera zaplavila hlubsi cast sklepa.");
                        System.out.println("Co udelas?\nJit si zaplavat[1]\nRadeji sve prozkoumavani zde skoncim a vydam se jinam[2]");

                        while (true) {

                            try {

                                int volba4 = vstup.nextInt();

                                if (volba4 == 1 || volba4 == 2) {

                                    if (volba4 == 1) {

                                        voda = true;

                                        System.out.println("Ponoris se do vody a v tu chvili si uvedomis co za strasnou chybu si udelal. Stavas se jeden z tech co vi!");
                                        System.out.println("Po tehle zkusenosti se se radeji rozhodl tve prozkouvani zde ukoncit a vydat se nekam jinam.");
                                        System.out.println("Podival si se do mapy a vidis, ze mas momentalne pet moznosti:\nJit do restaurace Masokoule Martina[1]\nJit do uzenarstvi Honzy Slaniny[2]\nJit se podivat na namesti[6]\nJit se podivat do metra[7]\nJit k barberovi[8]");

                                        while (true) {

                                            try {

                                                int lokace4 = vstup.nextInt();

                                                if (lokace4 == 1 || lokace4 == 2 || lokace4 == 6 || lokace4 == 7 || lokace4 == 8) {

                                                    lokace = lokace4;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [1], [2], [6], [7] nebo [8].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [1], [2], [6], [7] nebo [8].");

                                                vstup.nextLine();

                                            }

                                        }

                                    } else {

                                        System.out.println("Podival si se do mapy a vidis, ze mas momentalne pet moznosti:\nJit do restaurace Masokoule Martina[1]\nJit do uzenarstvi Honzy Slaniny[2]\nJit se podivat na namesti[6]\nJit se podivat do metra[7]\nJit k barberovi[8]");

                                        while (true) {

                                            try {

                                                int lokace4 = vstup.nextInt();

                                                if (lokace4 == 1 || lokace4 == 2 || lokace4 == 6 || lokace4 == 7 || lokace4 == 8) {

                                                    lokace = lokace4;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [1], [2], [6], [7] nebo [8].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [1], [2], [6], [7] nebo [8].");

                                                vstup.nextLine();

                                            }

                                        }

                                    }

                                    break;
                                } else {

                                    System.out.println("Napis [1] nebo [2].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }
                        }

                    }

                    break;

                case 5: //55555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555

                    if (navstiveno[lokace]) {

                        if (nabidka) {

                            System.out.println("Nabidka mistra Wu stale bezi.Co udelas?\nOdmitnout nabidku a vratit se do uzenarstvi Honzy Slaniny[2]\nZahodit vse za hlavu a odletel do Ciny se ucit Spinjitzu a Bankai[17]");

                            while (true) {

                                try {

                                    int volba51 = vstup.nextInt();

                                    if (volba51 == 2 || volba51 == 17) {

                                        if (volba51 == 2) {

                                            lokace = volba51;

                                            break;

                                        } else {

                                            lokace = volba51;

                                            break;

                                        }

                                    } else {

                                        System.out.println("Napis [2] nebo [17].");

                                    }

                                } catch (java.util.InputMismatchException e) {

                                    System.out.println("Napis [2] nebo [17].");

                                    vstup.nextLine();

                                }

                            }

                        } else {

                            System.out.println("V cinske ctvrti si sve  moznosti uz vypotreboval, a proto se vracis do uzenarstvi Honzy slaniny.");

                            lokace = 2;

                            break;

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Vchazis do mistni cinske ctvrti. Navstevujes hlavni sin a potkavas mistra Wu.Co udelas?\nVyzvat mistra Wu na MOG BATTLE[1]\nPopovidat si s mistrem Wu[2]");

                        while (true) {

                            try {

                                int volba5 = vstup.nextInt();

                                if (volba5 == 1 || volba5 == 2) {

                                    if (volba5 == 1) {

                                        System.out.println("Mistr Wu te totalne v MOG BATTLU rozbil. Ztracis 4 RIZZY.");

                                        RIZZ -= 4;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");
                                        System.out.println("Podival si se do mapy a zjistujes, ze odsud vede cesta pouze zpatky do uzenartsvi Honzy Slaniny");

                                        lokace = 2;

                                        break;

                                    } else {

                                        nabidka = true;

                                        System.out.println("Mistr Wu ti nabizi jedno z poslednich 6 moznych mist pro zucastneni se jeho doucovani Spinjitzu a Bankai v Cine.");

                                        System.out.println("Co udelas?\nOdmitnout nabidku a vratit se do uzenarstvi Honzy Slaniny[2]\nZahodit vse za hlavu a odletel do Ciny se ucit Spinjitzu a Bankai[17]");

                                        while (true) {

                                            try {

                                                int volba52 = vstup.nextInt();

                                                if (volba52 == 2 || volba52 == 17) {

                                                    if (volba52 == 17) {

                                                        lokace = volba52;

                                                        break;

                                                    } else {

                                                        lokace = volba52;

                                                        break;

                                                    }

                                                } else {

                                                    System.out.println("Napis [2] nebo [17].");
                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [2] nebo [17].");

                                                vstup.nextLine();

                                            }

                                        }

                                        break;

                                    }

                                } else {

                                    System.out.println("Napis [1] nebo [2].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }

                        }

                    }

                    break;

                case 6: //66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666

                    if (voda) {

                        if (navstiveno[lokace]) {

                            System.out.println("Na namesti sve moznosti uz vypotreboval.");
                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]");

                            while (true) {

                                try {

                                    int lokace6 = vstup.nextInt();

                                    if (lokace6 == 3 || lokace6 == 4 || lokace6 == 9 || lokace6 == 10) {

                                        lokace = lokace6;

                                        break;

                                    } else {

                                        System.out.println("Napis [3], [4], [10] nebo [11].");

                                    }

                                } catch (java.util.InputMismatchException e) {

                                    System.out.println("Napis [3], [4], [10] nebo [11].");

                                    vstup.nextLine();

                                }

                            }

                        } else {

                            navstiveno[lokace] = true;

                            System.out.println("Prichazis na namesti a po chvilce prochazeni si vsimas skupinky tech co vi, kteri na sobe davaji znat, ze vi, ze ty vis, a proto kdyz kolem tebe prochazi te vyzivaji na MOG BATTLE.");
                            System.out.println("Co udelas?\nVyzvat prijmu[1]\nRadeji se zbabele vyhnout souboji a ztratit rizz[2]");

                            while (true) {

                                try {

                                    int volba61 = vstup.nextInt();

                                    if (volba61 == 1 || volba61 == 2) {

                                        if (volba61 == 1) {

                                            System.out.println("Jelikoz ti co vi respektuji ty co vi nechavaji se v MOG BATTLU porazit a ty ziskavas 10 RIZZU.");

                                            RIZZ += 10;

                                            rizz();

                                            System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]");

                                            while (true) {

                                                try {

                                                    int lokace6 = vstup.nextInt();

                                                    if (lokace6 == 3 || lokace6 == 4 || lokace6 == 9 || lokace6 == 10) {

                                                        lokace = lokace6;

                                                        break;

                                                    } else {

                                                        System.out.println("Napis [3], [4], [9] nebo [10].");

                                                    }

                                                } catch (java.util.InputMismatchException e) {

                                                    System.out.println("Napis [3], [4], [9] nebo [10].");

                                                    vstup.nextLine();

                                                }

                                            }

                                            break;

                                        } else {

                                            System.out.println("Zbabele utikas pred MOG BATTLEM s temi co vi a ztracis 10 RIZZU.");

                                            RIZZ -= 10;

                                            rizz();

                                            System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]");

                                            while (true) {

                                                try {

                                                    int lokace6 = vstup.nextInt();

                                                    if (lokace6 == 3 || lokace6 == 4 || lokace6 == 9 || lokace6 == 10) {

                                                        lokace = lokace6;

                                                        break;

                                                    } else {

                                                        System.out.println("Napis [3], [4], [9] nebo [10].");

                                                    }

                                                } catch (java.util.InputMismatchException e) {

                                                    System.out.println("Napis [3], [4], [9] nebo [10].");

                                                    vstup.nextLine();

                                                }

                                            }

                                            break;

                                        }

                                    } else {

                                        System.out.println("Napis [1] nebo [2].");
                                    }

                                } catch (java.util.InputMismatchException e) {

                                    System.out.println("Napis [1] nebo [2].");

                                    vstup.nextLine();

                                }

                            }

                        }

                    } else {

                        if (navstiveno[lokace]) {

                            System.out.println("Na namesti sve moznosti uz vypotreboval.");
                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]");

                            while (true) {

                                try {

                                    int lokace6 = vstup.nextInt();

                                    if (lokace6 == 3 || lokace6 == 4 || lokace6 == 9 || lokace6 == 10) {

                                        lokace = lokace6;

                                        break;

                                    } else {

                                        System.out.println("Napis [3], [4], [10] nebo [11].");

                                    }

                                } catch (java.util.InputMismatchException e) {

                                    System.out.println("Napis [3], [4], [10] nebo [11].");

                                    vstup.nextLine();

                                }

                            }

                        } else {

                            navstiveno[lokace] = true;

                            System.out.println("Prichazis na namesti a po chvilce prochazeni si vsimas skupinky tech co vi, kteri na sobe davaji znat, ze vi, ze ty nevis, a proto kdyz kolem tebe prochazi te vyzivaji na MOG BATTLE.");
                            System.out.println("Co udelas?\nVyzvat prijmu[1]\nRadeji se zbabele vyhnout souboji a ztratit rizz[2]");

                            while (true) {

                                try {

                                    int volba6 = vstup.nextInt();

                                    if (volba6 == 1 || volba6 == 2) {

                                        if (volba6 == 1) {

                                            System.out.println("Jelikoz ti co vi nerespektuji ty co nevi a jejich na tebe hodne tak souboj jednoznacne prohravas a ztracis 6 RIZZU.");

                                            RIZZ -= 6;

                                            rizz();

                                            System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]");

                                            while (true) {

                                                try {

                                                    int lokace6 = vstup.nextInt();

                                                    if (lokace6 == 3 || lokace6 == 4 || lokace6 == 9 || lokace6 == 10) {

                                                        lokace = lokace6;

                                                        break;

                                                    } else {

                                                        System.out.println("Napis [3], [4], [9] nebo [10].");

                                                    }

                                                } catch (java.util.InputMismatchException e) {

                                                    System.out.println("Napis [3], [4], [9] nebo [10].");

                                                    vstup.nextLine();

                                                }

                                            }

                                            break;

                                        } else {

                                            System.out.println("Zbabele utikas pred MOG BATTLEM s temi co vi a ztracis 4 RIZZY.");

                                            RIZZ -= 4;

                                            rizz();

                                            System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]");

                                            while (true) {

                                                try {

                                                    int lokace6 = vstup.nextInt();

                                                    if (lokace6 == 3 || lokace6 == 4 || lokace6 == 9 || lokace6 == 10) {

                                                        lokace = lokace6;

                                                        break;

                                                    } else {

                                                        System.out.println("Napis [3], [4], [9] nebo [10].");

                                                    }

                                                } catch (java.util.InputMismatchException e) {

                                                    System.out.println("Napis [3], [4], [9] nebo [10].");

                                                    vstup.nextLine();

                                                }

                                            }

                                            break;

                                        }

                                    } else {

                                        System.out.println("Napis [1] nebo [2].");
                                    }

                                } catch (java.util.InputMismatchException e) {

                                    System.out.println("Napis [1] nebo [2].");

                                    vstup.nextLine();

                                }

                            }

                        }

                    }

                    break;

                case 7: //7777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777

                    if (navstiveno[lokace]) {

                        System.out.println("V metru si sve moznosti uz vypotreboval.\nPodival si se do mapy a vidis, ze mas momentalne ctyri moznosti:\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do McDonalds[10]\nJit se podivat do nemocnice[11]");

                        while (true) {

                            try {

                                int lokace7 = vstup.nextInt();

                                if (lokace7 == 3 || lokace7 == 4 || lokace7 == 10 || lokace7 == 11) {

                                    lokace = lokace7;

                                    break;

                                } else {

                                    System.out.println("Napis [3], [4], [10] nebo [11].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [3], [4], [10] nebo [11].");

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Vchazis do stanice metra a potkavas sigma kluka s jeho velkym reprakem hrajicim na plne pecky banger sigma kluk.Sigma kluk dela backflip a vyzyva te na MOG BATTLE.");
                        System.out.println("Co udelas?Vyzvat prijmu[1]Utect a ztratit tim RIZZ[2]");

                        while (true) {

                            try {

                                int volba7 = vstup.nextInt();

                                if (volba7 == 1 || volba7 == 2) {

                                    if (volba7 == 1) {

                                        rizz();

                                        System.out.println("Vyzval si prijmu od sigma kluka.");

                                        int aura1 = 100;
                                        int aura2 = 100;

                                        rizz();

                                        while (aura1 > 0 && aura2 > 0) {

                                            int damage2 = (int) (random.nextInt(41) * 1.2);

                                            aura1 -= damage2;

                                            System.out.println("Pohled sigma kluka te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nSigma kluk aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura1 <= 0) {

                                                System.out.println("V MOG BATTLU si prohral");

                                                System.out.println("Prave si prisel 2 RIZZY.");

                                                RIZZ -= 2;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do McDonalds[10]\nJit se podivat do nemocnice[11]");

                                                while (true) {

                                                    try {

                                                        int lokace7 = vstup.nextInt();

                                                        if (lokace7 == 3 || lokace7 == 4 || lokace7 == 10 || lokace7 == 11) {

                                                            lokace = lokace7;

                                                            break;

                                                        } else {

                                                            System.out.println("Napis [3], [4], [10] nebo [11].");

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        System.out.println("Napis [3], [4], [10] nebo [11].");

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                            int damage1 = (int) (random.nextInt(41) * nasobic);

                                            aura2 -= damage1;

                                            System.out.println("Tvuj pohled zasahl sigma kluka za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nSgima kluk aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura2 <= 0) {

                                                System.out.println("V MOG BATTLU si vyhral.");

                                                System.out.println("Prave si ziskal 8 RIZZU.");

                                                RIZZ += 8;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do McDonalds[10]\nJit se podivat do nemocnice[11]");

                                                while (true) {

                                                    try {

                                                        int lokace7 = vstup.nextInt();

                                                        if (lokace7 == 3 || lokace7 == 4 || lokace7 == 10 || lokace7 == 11) {

                                                            lokace = lokace7;

                                                            break;

                                                        } else {

                                                            System.out.println("Napis [3], [4], [10] nebo [11].");

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        System.out.println("Napis [3], [4], [10] nebo [11].");

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                        }

                                    } else {

                                        System.out.println("Utikas pred MOG BATTLEM se sigma klukem a ztracis tim 2 RIZZY.");

                                        RIZZ -= 2;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit se podivat do parku[3]\nJit poznat sve chakry[4]\nJit do McDonalds[10]\nJit se podivat do nemocnice[11]");

                                        while (true) {

                                            try {

                                                int lokace7 = vstup.nextInt();

                                                if (lokace7 == 3 || lokace7 == 4 || lokace7 == 10 || lokace7 == 11) {

                                                    lokace = lokace7;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [3], [4], [10] nebo [11].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [3], [4], [10] nebo [11].");

                                                vstup.nextLine();

                                            }

                                        }

                                        break;

                                    }

                                    break;

                                } else {

                                    System.out.println("Napis [1] nebo [2].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }
                        }

                    }

                    break;

                case 8: //8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888

                    if (navstiveno[lokace]) {

                        System.out.println("U barbera si sve moznosti uz vypotreboval.\nPodival si se do mapy a vidis, ze mas momentalne tri moznosti:\nJit do opustene budovy[4]\nJit se podivat do nemocnice[11]\nJit k pramenu reky Ohio[12]");

                        while (true) {

                            try {

                                int lokace8 = vstup.nextInt();

                                if (lokace8 == 4 || lokace8 == 11 || lokace8 == 12) {

                                    lokace = lokace8;

                                    break;

                                } else {

                                    System.out.println("Napis [4], [11] nebo [12].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [4], [11] nebo [12].");

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Prichazis k barberovi a vidis znameho streamera Nijnu, ze se prave ted na jednom z mist nechava strihat.");
                        System.out.println("Co udelas?\nNechat si udelat novy sestrih[1]\nPopovidat si s Ninjou[2]");

                        while (true) {

                            try {

                                int volba8 = vstup.nextInt();

                                if (volba8 == 1 || volba8 == 2) {

                                    if (volba8 == 1) {

                                        System.out.println("Bohuzel jako vzdy se novy strih nepovedl a ty ztracis 4 RIZZY.");

                                        RIZZ -= 4;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit poznat sve chakry[4]\nJit se podivat do nemocnice[11]\nJit k pramenu reky Ohio[12]");

                                        while (true) {

                                            try {

                                                int lokace8 = vstup.nextInt();

                                                if (lokace8 == 4 || lokace8 == 11 || lokace8 == 12) {

                                                    lokace = lokace8;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [4], [11] nebo [12].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [4], [11] nebo [12].");

                                                vstup.nextLine();

                                            }

                                        }

                                    } else {

                                        System.out.println("Zacinas konverzaci s Ninjou ten je, ale velmi arogantni a jen ti doporuci sestrih jmenem nizke vyblednuti kuzele, ktery je podle jeho slov stale masivni trend.");
                                        System.out.println("Das na jeho slova i presto jak neprijemny byl?\nAno[1]\n[2]");

                                        while (true) {

                                            try {

                                                int volba81 = vstup.nextInt();

                                                if (volba81 == 1 || volba81 == 2) {

                                                    if (volba81 == 1) {

                                                        System.out.println("Sestrih nizkeho vyblednuteho kuzele je doopravdy masivni. Ziskava 6 RIZZU.");

                                                        RIZZ += 6;

                                                        rizz();

                                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                        System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit poznat sve chakry[4]\nJit se podivat do nemocnice[11]\nJit k pramenu reky Ohio[12]");

                                                        while (true) {

                                                            try {

                                                                int lokace8 = vstup.nextInt();

                                                                if (lokace8 == 4 || lokace8 == 11 || lokace8 == 12) {

                                                                    lokace = lokace8;

                                                                    break;

                                                                } else {

                                                                    System.out.println("Napis [4], [11] nebo [12].");

                                                                }

                                                            } catch (java.util.InputMismatchException e) {

                                                                System.out.println("Napis [4], [11] nebo [12].");

                                                                vstup.nextLine();

                                                            }

                                                        }

                                                    } else {

                                                        System.out.println("Nenechavas si poradit a nechavas si udelat svuj klasicky strih a jako vzdy vypada strasne. Ztracis 4 RIZZY.");

                                                        RIZZ -= 4;

                                                        rizz();

                                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                        System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit poznat sve chakry[4]\nJit se podivat do nemocnice[11]\nJit k pramenu reky Ohio[12]");

                                                        while (true) {

                                                            try {

                                                                int lokace8 = vstup.nextInt();

                                                                if (lokace8 == 4 || lokace8 == 11 || lokace8 == 12) {

                                                                    lokace = lokace8;

                                                                    break;

                                                                } else {

                                                                    System.out.println("Napis [4], [11] nebo [12].");

                                                                }

                                                            } catch (java.util.InputMismatchException e) {

                                                                System.out.println("Napis [4], [11] nebo [12].");

                                                                vstup.nextLine();

                                                            }

                                                        }

                                                    }

                                                } else {

                                                    System.out.println("Napis [1] nebo [2]");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [1] nebo [2]");

                                                vstup.nextLine();

                                            }

                                        }

                                    }

                                } else {

                                    System.out.println("Napis [1] nebo [2].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }

                            break;

                        }

                    }

                    break;

                case 9: //9999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999

                    if (navstiveno[lokace]) {

                        System.out.println("V balkanske ctvrti si sve moznosti uz vypotreboval.\nPodival si se do mapy a odsud mas dve moznosti:\nJit do klubu[13]\nJit do kralosvstvi Skibidialni toalety[16]");

                        while (true) {

                            try {

                                int lokace9 = vstup.nextInt();

                                if (lokace9 == 13 || lokace9 == 16) {

                                    lokace = lokace9;

                                    break;

                                } else {

                                    System.out.println("Napis [13] nebo [16].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [13] nebo [16].");

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Prichazis do balkanske ctvrti, kde se nedej nic neobvykleho do te doby co si chces zkratit cestu a zahnes do cerne ulicky, kde jako by na primo na tebe cekalo vzteleni balkanskeho vzteku a vyzyva te na MOG BATTLE.");
                        System.out.println("Co udelas?\nPokusit se utect a ztratit hodne RIZZU[1]\nRisknout MOG BATTLE se ztelenim balkanskeho vzteku[2]");

                        while (true) {

                            try {

                                int volba9 = vstup.nextInt();

                                if (volba9 == 1 || volba9 == 2) {

                                    if (volba9 == 1) {

                                        rizz();

                                        System.out.println("Vyzval si prijmu od zteleni balkanskeho vzteku.");

                                        int aura1 = 100;
                                        int aura2 = 100;

                                        rizz();

                                        while (aura1 > 0 && aura2 > 0) {

                                            int damage2 = (int) (random.nextInt(41) * 1.2);

                                            aura1 -= damage2;

                                            System.out.println("Pohled zteleni balkanskeho vzteku te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nZteleni balkanskeho vzteku aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura1 <= 0) {

                                                System.out.println("V MOG BATTLU si prohral");

                                                System.out.println("Prave si prisel 8 RIZZU.");

                                                RIZZ -= 8;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                System.out.println("Podival si se do mapy a odsud mas dve moznosti:\nJit do klubu[13]\nJit do kralosvstvi Skibidialni toalety[16]");

                                                while (true) {

                                                    try {

                                                        int lokace9 = vstup.nextInt();

                                                        if (lokace9 == 13 || lokace9 == 16) {

                                                            lokace = lokace9;

                                                            break;

                                                        } else {

                                                            System.out.println("Napis [13] nebo [16].");

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        System.out.println("Napis [13] nebo [16].");

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                            int damage1 = (int) (random.nextInt(41) * nasobic);

                                            aura2 -= damage1;

                                            System.out.println("Tvuj pohled zasahl zteleni balkanskeho vzteku za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nZteleni balkanskeho vzteku aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura2 <= 0) {

                                                System.out.println("V MOG BATTLU si vyhral.");

                                                System.out.println("Prave si ziskal 10 RIZZU.");

                                                RIZZ += 10;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                System.out.println("Podival si se do mapy a odsud mas dve moznosti:\nJit do klubu[13]\nJit do kralosvstvi Skibidialni toalety[16]");

                                                while (true) {

                                                    try {

                                                        int lokace9 = vstup.nextInt();

                                                        if (lokace9 == 13 || lokace9 == 16) {

                                                            lokace = lokace9;

                                                            break;

                                                        } else {

                                                            System.out.println("Napis [13] nebo [16].");

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        System.out.println("Napis [13] nebo [16].");

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                        }

                                    } else {

                                        System.out.println("Utikas pred MOG BATTLEM se ztelenim balkanskeho vzteku a ztracis tim 8 RIZZU.");

                                        RIZZ -= 8;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas dve moznosti:\nJit do klubu[13]\nJit do kralosvstvi Skibidialni toalety[16");

                                        while (true) {

                                            try {

                                                int lokace9 = vstup.nextInt();

                                                if (lokace9 == 13 || lokace9 == 16) {

                                                    lokace = lokace9;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [13] nebo [16].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [13] nebo [16].");

                                                vstup.nextLine();

                                            }

                                        }

                                        break;

                                    }

                                    break;

                                } else {

                                    System.out.println("Napis [1] nebo [2].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }
                        }

                    }

                    break;

                case 10: //101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010

                    if (navstiveno[lokace]) {

                        System.out.println("V McDonalds si sve moznosti uz vypotreboval.\nPodival si se do mapy a odsud mas dve moznosti:\nJit do klubu[13]\nJit do cukrarstvi[14]");

                        while (true) {

                            try {

                                int lokace10 = vstup.nextInt();

                                if (lokace10 == 13 || lokace10 == 14) {

                                    lokace = lokace10;

                                    break;

                                } else {

                                    System.out.println("Napis [13] nebo [14].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [13] nebo [14].");

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Prichazis do mistniho McDonalds a vidis znamou infleuncerka Gorlock.\nCo udelas?\nVyzvat Gorlocka na MOG BATTLE[1]Dat si chesse a odejit[2]");

                        while (true) {

                            try {

                                int volba10 = vstup.nextInt();

                                if (volba10 == 1 || volba10 == 2) {

                                    if (volba10 == 1) {

                                        System.out.println("Vyzvat Gorlocka na MOG BATTLE je od tebe primo ponizujici. Ztracis 10 RIZZU.");

                                        RIZZ -= 10;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas dve moznosti:\nJit do klubu[13]\nJit do cukrarstvi[14]");

                                        while (true) {

                                            try {

                                                int lokace10 = vstup.nextInt();

                                                if (lokace10 == 13 || lokace10 == 14) {

                                                    lokace = lokace10;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [13] nebo [14].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [13] nebo [14].");

                                                vstup.nextLine();

                                            }

                                        }

                                    } else {

                                        System.out.println("Davat si chesse takhle blizko tvemu cili neni zrovna nejchytrejsi a nejlepsi pro tvou celistni linii. Ztracis 2 RIZZY.");

                                        RIZZ -= 2;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas dve moznosti:\nJit do klubu[13]\nJit do cukrarstvi[14]");

                                        while (true) {

                                            try {

                                                int lokace10 = vstup.nextInt();

                                                if (lokace10 == 13 || lokace10 == 14) {

                                                    lokace = lokace10;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [13] nebo [14].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [13] nebo [14].");

                                                vstup.nextLine();

                                            }

                                        }

                                    }

                                } else {

                                    System.out.println("Napis [1] nebo [2].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }

                        }

                    }

                    break;

                case 11: //1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111

                    if (navstiveno[lokace]) {

                        System.out.println("V nemocnici si sve moznosti uz vypotreboval.\nPodival si se do mapy a odsud mas dve moznosti:\nJit do cukrarstvi[14]\nJit na prochazku[15]");

                        while (true) {

                            try {

                                int lokace11 = vstup.nextInt();

                                if (lokace11 == 14 || lokace11 == 15) {

                                    lokace = lokace11;

                                    break;

                                } else {

                                    System.out.println("Napis [14] nebo [15].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [14] nebo [15].");

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Prichazis do nemocnice, kde si nechavas udelat beznou prohlidku a zjistujes, ze zitra budes muset podstoupit operaci kolene.");
                        System.out.println("Co udelas?\nJit zitra na operaci kolene[1]\nNatocit video o tvych poticech o tom, ze zitra te ceka operace kolene[2]");

                        while (true) {

                            try {

                                int volba11 = vstup.nextInt();

                                if (volba11 == 1 || volba11 == 2) {

                                    if (volba11 == 1) {

                                        System.out.println("Dalsi den jdes na operaci kolene, ale bohuzel si doktor spletl kolena a ted obe dve tva kolena nejsou v nejlepsim stavu. Ztracis 4 RIZZY.");

                                        RIZZ -= 4;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas dve moznosti:\nJit do cukrarstvi[14]\nJit na prochazku[15]");

                                        while (true) {

                                            try {

                                                int lokace11 = vstup.nextInt();

                                                if (lokace11 == 14 || lokace11 == 15) {

                                                    lokace = lokace11;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [14] nebo [15].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [14] nebo [15].");

                                                vstup.nextLine();

                                            }

                                        }

                                    } else {

                                        System.out.println("Natocil si tiktok o pocitu kdyz operace kolene je zitra. Video ziskava obri popularitu a tim ziskavas 10 RIZZU.");

                                        RIZZ += 10;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        System.out.println("Podival si se do mapy a odsud mas dve moznosti:\nJit do cukrarstvi[14]\nJit na prochazku[15]");

                                        while (true) {

                                            try {

                                                int lokace11 = vstup.nextInt();

                                                if (lokace11 == 14 || lokace11 == 15) {

                                                    lokace = lokace11;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [14] nebo [15].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [14] nebo [15].");

                                                vstup.nextLine();

                                            }

                                        }

                                    }

                                } else {

                                    System.out.println("Napis [1] nebo [2].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }

                        }

                    }

                    break;

                case 12: //121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212

                    if (navstiveno[lokace]) {

                        System.out.println("U pramene reky Ohio si sve moznosti uz vypotreboval.\nPodival si se do mapy a odsud mas dve moznosti:\nJit na prochazku[15]\nJit do kralovstvi Skibidialni toalety[16]");

                        while (true) {

                            try {

                                int lokace12 = vstup.nextInt();

                                if (lokace12 == 15 || lokace12 == 16) {

                                    lokace = lokace12;

                                    break;

                                } else {

                                    System.out.println("Napis [15] nebo [16].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [15] nebo [16].");

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Prichazis k pramenu reky Ohio kde potkavas samotneho popularniho rappera poseiodona Ohia a ten ti nabizi, ze jestli odpovis na jeho otazku tak te da na jeho instagram pribeh.");
                        System.out.println("Co udelas?\nOdpovedet na otazku[1]\nVyzvat poseidona Ohia na MOG BATTLE[2]");

                        while (true) {

                            try {

                                int volba12 = vstup.nextInt();

                                if (volba12 == 1 || volba12 == 2) {

                                    if (volba12 == 1) {

                                        System.out.println("Poseidon Ohia te zacina natacet svym Iphonem a rika ti:\n\"Dopln text pisnicky,\nod obrazovky k ringu,...\"");
                                        System.out.println("a)ke krali, k peru[a]\nb)ke krali. Kde je moje koruna?[2]\nc)ke korune, k peru[c]\nd)k peru, ke krali.[d]");

                                        while (true) {

                                            try {

                                                String text = vstup.nextLine();

                                                if (text.equals("a") || text.equals("b") || text.equals("c") || text.equals("d")) {

                                                    switch (text) {

                                                        case "a":

                                                            System.out.println("Spatna odpoved! Jsi ponizen na instagramu poseiodna Ohia. Ztracis 4 RIZZY.");

                                                            RIZZ -= 4;

                                                            rizz();

                                                            System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                            break;

                                                        case "b":

                                                            System.out.println("Spatna odpoved! Jsi ponizen na instagramu poseiodna Ohia. Ztracis 4 RIZZY.");

                                                            RIZZ -= 4;

                                                            rizz();

                                                            System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                            break;

                                                        case "c":

                                                            System.out.println("Spatna odpoved! Jsi ponizen na instagramu poseiodna Ohia. Ztracis 4 RIZZY.");

                                                            RIZZ -= 4;

                                                            rizz();

                                                            System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                            break;

                                                        case "d":

                                                            System.out.println("Spravna odpoved! Na instagramovem pribehu poseidona Ohia jsi za frajera. Ziskavas 6 RIZZU.");

                                                            RIZZ += 6;

                                                            rizz();

                                                            System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                            break;

                                                    }

                                                    break;

                                                } else {

                                                    System.out.println("Napis [a], [b], [c] nebo [d].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [a], [b], [c] nebo [d].");

                                                vstup.nextLine();

                                            }

                                        }

                                        System.out.println("Podival si se do mapy a odsud mas dve moznosti:\nJit do cukrarstvi[14]\nJit na prochazku[15]");

                                        while (true) {

                                            try {

                                                int lokace12 = vstup.nextInt();

                                                if (lokace12 == 15 || lokace12 == 16) {

                                                    lokace = lokace12;

                                                    break;

                                                } else {

                                                    System.out.println("Napis [15] nebo [16].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [15] nebo [16].");

                                                vstup.nextLine();

                                            }

                                        }

                                    } else {

                                        rizz();

                                        System.out.println("Vyzval si poseidona Ohia na MOG BATTLE.");

                                        int aura1 = 100;
                                        int aura2 = 100;

                                        rizz();

                                        while (aura1 > 0 && aura2 > 0) {

                                            int damage1 = (int) (random.nextInt(41) * nasobic);

                                            aura1 -= damage1;

                                            System.out.println("Tvuj pohled zasahl poseidona Ohia za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nPoseidona Ohia aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura2 <= 0) {

                                                System.out.println("V MOG BATTLU si vyhral");

                                                System.out.println("Prave si ziskal 8 RIZZU.");

                                                RIZZ += 8;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                System.out.println("Podival si se do mapy a odsud mas dve moznosti:\nJit do cukrarstvi[14]\nJit na prochazku[15]");

                                                while (true) {

                                                    try {

                                                        int lokace12 = vstup.nextInt();

                                                        if (lokace12 == 15 || lokace12 == 16) {

                                                            lokace = lokace12;

                                                            break;

                                                        } else {

                                                            System.out.println("Napis [15] nebo [16].");

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        System.out.println("Napis [15] nebo [16].");

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                            int damage2 = (int) (random.nextInt(41) * 1.6);

                                            aura1 -= damage2;

                                            System.out.println("Pohled poseidona Ohia te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nPoseidona Ohia aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura1 <= 0) {

                                                System.out.println("V MOG BATTLU si prohral.");

                                                System.out.println("Prave si prisel o 6 RIZZU.");

                                                RIZZ -= 6;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                System.out.println("Podival si se do mapy a odsud mas dve moznosti:\nJit do cukrarstvi[14]\nJit na prochazku[15]");

                                                while (true) {

                                                    try {

                                                        int lokace12 = vstup.nextInt();

                                                        if (lokace12 == 15 || lokace12 == 16) {

                                                            lokace = lokace12;

                                                            break;

                                                        } else {

                                                            System.out.println("Napis [15] nebo [16].");

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        System.out.println("Napis [15] nebo [16].");

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                        }

                                    }

                                } else {

                                    System.out.println("Napis [1] nebo [2].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }

                        }

                    }

                    break;

                case 13:

                    if (navstiveno[lokace]) {

                        System.out.println("V klubu si sve moznosti uz vypotreboval.");

                        if (cina) {

                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                        } else {

                            System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]");

                        }

                        while (true) {

                            try {

                                int lokace13 = vstup.nextInt();

                                if (lokace13 == 9 || lokace13 == 10 || lokace13 == 16 || lokace13 == 17 && cina == true) {

                                    lokace = lokace13;

                                    break;

                                } else {

                                    if (cina) {

                                        System.out.println("Napis [9], [10], [16] nebo [17].");

                                    } else {

                                        System.out.println("Napis [9], [10] nebo [16].");

                                    }

                                }

                            } catch (java.util.InputMismatchException e) {

                                if (cina) {

                                    System.out.println("Napis [9], [10], [16] nebo [17].");

                                } else {

                                    System.out.println("Napis [9], [10] nebo [16].");

                                }

                                vstup.nextLine();

                            }

                        }

                    } else {

                        navstiveno[lokace] = true;

                        System.out.println("Prichazis do klubu, kde zrovna probiha tiktok rizz party. Vidis tancrecky quandle dingleovat ctyri kluky, ktereho z nich vyzves na MOG BATTLE?");
                        System.out.println("Rajcatovy kluk[1]Kluk s bilym trickem[2]Turecky quandle dingle[3]Kluk s modrou kravatou[4]");

                        while (true) {

                            try {

                                int volba13 = vstup.nextInt();

                                if (volba13 == 1 || volba13 == 2 || volba13 == 3 || volba13 == 4) {

                                    if (volba13 == 1) {

                                        rizz();

                                        System.out.println("Vyzval si rajcatoveho kluka na MOG BATTLE.");

                                        int aura1 = 100;
                                        int aura2 = 100;

                                        rizz();

                                        while (aura1 > 0 && aura2 > 0) {

                                            int damage1 = (int) (random.nextInt(41) * nasobic);

                                            aura2 -= damage1;

                                            System.out.println("Tvuj pohled zasahl rajcatoveho kluka za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nRajcatovy kluka aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura2 <= 0) {

                                                System.out.println("V MOG BATTLU si vyhral");

                                                System.out.println("Prave si ziskal 2 RIZZY.");

                                                RIZZ += 2;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                if (cina) {

                                                    System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                                } else {

                                                    System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]");

                                                }

                                                while (true) {

                                                    try {

                                                        int lokace13 = vstup.nextInt();

                                                        if (lokace13 == 9 || lokace13 == 10 || lokace13 == 16 || lokace13 == 17 && cina == true) {

                                                            lokace = lokace13;

                                                            break;

                                                        } else {

                                                            if (cina) {

                                                                System.out.println("Napis [9], [10], [16] nebo [17].");

                                                            } else {

                                                                System.out.println("Napis [9], [10] nebo [16].");

                                                            }

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        if (cina) {

                                                            System.out.println("Napis [9], [10], [16] nebo [17].");

                                                        } else {

                                                            System.out.println("Napis [9], [10] nebo [16].");

                                                        }

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                            int damage2 = (int) (random.nextInt(41) * 1.2);

                                            aura1 -= damage2;

                                            System.out.println("Pohled rajcatoveho kluka te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nRajcatovy kluk aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura1 <= 0) {

                                                System.out.println("V MOG BATTLU si prohral.");

                                                System.out.println("Prave si prisel o 2 RIZZY.");

                                                RIZZ -= 2;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                if (cina) {

                                                    System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                                } else {

                                                    System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]");

                                                }

                                                while (true) {

                                                    try {

                                                        int lokace13 = vstup.nextInt();

                                                        if (lokace13 == 9 || lokace13 == 10 || lokace13 == 16 || lokace13 == 17 && cina == true) {

                                                            lokace = lokace13;

                                                            break;

                                                        } else {

                                                            if (cina) {

                                                                System.out.println("Napis [9], [10], [16] nebo [17].");

                                                            } else {

                                                                System.out.println("Napis [9], [10] nebo [16].");

                                                            }

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        if (cina) {

                                                            System.out.println("Napis [9], [10], [16] nebo [17].");

                                                        } else {

                                                            System.out.println("Napis [9], [10] nebo [16].");

                                                        }

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                        }

                                    } else if (volba13 == 2) {

                                        rizz();

                                        System.out.println("Vyzval si kluka s bilym trickem na MOG BATTLE.");

                                        int aura1 = 100;
                                        int aura2 = 100;

                                        rizz();

                                        while (aura1 > 0 && aura2 > 0) {

                                            int damage1 = (int) (random.nextInt(41) * nasobic);

                                            aura2 -= damage1;

                                            System.out.println("Tvuj pohled zasahl kluka s bilym trickem za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nKluk s bilym trickem aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura2 <= 0) {

                                                System.out.println("V MOG BATTLU si vyhral");

                                                System.out.println("Prave si ziskal 4 RIZZY.");

                                                RIZZ += 4;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                if (cina) {

                                                    System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                                } else {

                                                    System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]");

                                                }

                                                while (true) {

                                                    try {

                                                        int lokace13 = vstup.nextInt();

                                                        if (lokace13 == 9 || lokace13 == 10 || lokace13 == 16 || lokace13 == 17 && cina == true) {

                                                            lokace = lokace13;

                                                            break;

                                                        } else {

                                                            if (cina) {

                                                                System.out.println("Napis [9], [10], [16] nebo [17].");

                                                            } else {

                                                                System.out.println("Napis [9], [10] nebo [16].");

                                                            }

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        if (cina) {

                                                            System.out.println("Napis [9], [10], [16] nebo [17].");

                                                        } else {

                                                            System.out.println("Napis [9], [10] nebo [16].");

                                                        }

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                            int damage2 = (int) (random.nextInt(41) * 1.2);

                                            aura1 -= damage2;

                                            System.out.println("Pohled klukas bilym trickem te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nKluk s bilym trickem aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura1 <= 0) {

                                                System.out.println("V MOG BATTLU si prohral.");

                                                System.out.println("Prave si prisel o 4 RIZZY.");

                                                RIZZ -= 4;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                if (cina) {

                                                    System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                                } else {

                                                    System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]");

                                                }

                                                while (true) {

                                                    try {

                                                        int lokace13 = vstup.nextInt();

                                                        if (lokace13 == 9 || lokace13 == 10 || lokace13 == 16 || lokace13 == 17 && cina == true) {

                                                            lokace = lokace13;

                                                            break;

                                                        } else {

                                                            if (cina) {

                                                                System.out.println("Napis [9], [10], [16] nebo [17].");

                                                            } else {

                                                                System.out.println("Napis [9], [10] nebo [16].");

                                                            }

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        if (cina) {

                                                            System.out.println("Napis [9], [10], [16] nebo [17].");

                                                        } else {

                                                            System.out.println("Napis [9], [10] nebo [16].");

                                                        }

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                        }

                                    } else if (volba13 == 3) {

                                        rizz();

                                        System.out.println("Vyzval si tureckeho quandle dingle na MOG BATTLE.");

                                        int aura1 = 100;
                                        int aura2 = 100;

                                        rizz();

                                        while (aura1 > 0 && aura2 > 0) {

                                            int damage1 = (int) (random.nextInt(41) * nasobic);

                                            aura2 -= damage1;

                                            System.out.println("Tvuj pohled zasahl tureckeho quandle dingle za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nTurecky quandle dingle aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura2 <= 0) {

                                                System.out.println("V MOG BATTLU si vyhral");

                                                System.out.println("Prave si ziskal 6 RIZZU.");

                                                RIZZ += 6;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                if (cina) {

                                                    System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                                } else {

                                                    System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]");

                                                }

                                                while (true) {

                                                    try {

                                                        int lokace13 = vstup.nextInt();

                                                        if (lokace13 == 9 || lokace13 == 10 || lokace13 == 16 || lokace13 == 17 && cina == true) {

                                                            lokace = lokace13;

                                                            break;

                                                        } else {

                                                            if (cina) {

                                                                System.out.println("Napis [9], [10], [16] nebo [17].");

                                                            } else {

                                                                System.out.println("Napis [9], [10] nebo [16].");

                                                            }

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        if (cina) {

                                                            System.out.println("Napis [9], [10], [16] nebo [17].");

                                                        } else {

                                                            System.out.println("Napis [9], [10] nebo [16].");

                                                        }

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                            int damage2 = (int) (random.nextInt(41) * 1.2);

                                            aura1 -= damage2;

                                            System.out.println("Pohled tureckeho quandle dingle te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nTurecky quandle dingle aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura1 <= 0) {

                                                System.out.println("V MOG BATTLU si prohral.");

                                                System.out.println("Prave si prisel o 6 RIZZU.");

                                                RIZZ -= 6;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                if (cina) {

                                                    System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                                } else {

                                                    System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]");

                                                }

                                                while (true) {

                                                    try {

                                                        int lokace13 = vstup.nextInt();

                                                        if (lokace13 == 9 || lokace13 == 10 || lokace13 == 16 || lokace13 == 17 && cina == true) {

                                                            lokace = lokace13;

                                                            break;

                                                        } else {

                                                            if (cina) {

                                                                System.out.println("Napis [9], [10], [16] nebo [17].");

                                                            } else {

                                                                System.out.println("Napis [9], [10] nebo [16].");

                                                            }

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        if (cina) {

                                                            System.out.println("Napis [9], [10], [16] nebo [17].");

                                                        } else {

                                                            System.out.println("Napis [9], [10] nebo [16].");

                                                        }

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                        }

                                    } else {

                                        rizz();

                                        System.out.println("Vyzval si kluka s modrou kravatou na MOG BATTLE.");

                                        int aura1 = 100;
                                        int aura2 = 100;

                                        rizz();

                                        while (aura1 > 0 && aura2 > 0) {

                                            int damage1 = (int) (random.nextInt(41) * nasobic);

                                            aura2 -= damage1;

                                            System.out.println("Tvuj pohled zasahl kluka s modrou kravatou za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nKluk s modrou kravatou aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura2 <= 0) {

                                                System.out.println("V MOG BATTLU si vyhral");

                                                System.out.println("Prave si ziskal 8 RIZZU.");

                                                RIZZ += 8;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                if (cina) {

                                                    System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                                } else {

                                                    System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]");

                                                }

                                                while (true) {

                                                    try {

                                                        int lokace13 = vstup.nextInt();

                                                        if (lokace13 == 9 || lokace13 == 10 || lokace13 == 16 || lokace13 == 17 && cina == true) {

                                                            lokace = lokace13;

                                                            break;

                                                        } else {

                                                            if (cina) {

                                                                System.out.println("Napis [9], [10], [16] nebo [17].");

                                                            } else {

                                                                System.out.println("Napis [9], [10] nebo [16].");

                                                            }

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        if (cina) {

                                                            System.out.println("Napis [9], [10], [16] nebo [17].");

                                                        } else {

                                                            System.out.println("Napis [9], [10] nebo [16].");

                                                        }

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                            int damage2 = (int) (random.nextInt(41) * 1.2);

                                            aura1 -= damage2;

                                            System.out.println("Pohled kluka s modrou kravatou te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nKluk s modrou kravatou aura: " + aura2);

                                            vstup.nextLine();

                                            if (aura1 <= 0) {

                                                System.out.println("V MOG BATTLU si prohral.");

                                                System.out.println("Prave si prisel o 8 RIZZU.");

                                                RIZZ -= 8;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                if (cina) {

                                                    System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                                } else {

                                                    System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do balkanske ctvrti[9]\nJit do McDonalds[10]\nJit do kralovstvi Skibidialni toalety[16]");

                                                }

                                                while (true) {

                                                    try {

                                                        int lokace13 = vstup.nextInt();

                                                        if (lokace13 == 9 || lokace13 == 10 || lokace13 == 16 || lokace13 == 17 && cina == true) {

                                                            lokace = lokace13;

                                                            break;

                                                        } else {

                                                            if (cina) {

                                                                System.out.println("Napis [9], [10], [16] nebo [17].");

                                                            } else {

                                                                System.out.println("Napis [9], [10] nebo [16].");

                                                            }

                                                        }

                                                    } catch (java.util.InputMismatchException e) {

                                                        if (cina) {

                                                            System.out.println("Napis [9], [10], [16] nebo [17].");

                                                        } else {

                                                            System.out.println("Napis [9], [10] nebo [16].");

                                                        }

                                                        vstup.nextLine();

                                                    }

                                                }

                                                break;

                                            }

                                        }

                                    }

                                } else {

                                    System.out.println("Napis [1], [2], [3] nebo [4].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1], [2], [3] nebo [4].");

                                vstup.nextLine();

                            }

                        }

                    }

                    break;

                case 14:

                    if (navstiveno[lokace]) {

                        System.out.println("V parku si sve moznosti uz vypotreboval.");

                        if (cina) {

                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do McDonalds[10]\nJit do nemocnice[11]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                        } else {

                            System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do McDonalds[10]\nJit do nemocnice[11]\nJit do kralovstvi Skibidialni toalety[16]");

                        }

                        while (true) {

                            try {

                                int lokace14 = vstup.nextInt();

                                if (lokace14 == 10 || lokace14 == 11 || lokace14 == 16 || lokace14 == 17 && cina == true) {

                                    lokace = lokace14;

                                    break;

                                } else {

                                    if (cina) {

                                        System.out.println("Napis [10], [11], [16] nebo [17].");

                                    } else {

                                        System.out.println("Napis [10], [11] nebo [16].");

                                    }

                                }

                            } catch (java.util.InputMismatchException e) {

                                if (cina) {

                                    System.out.println("Napis [10], [11], [16] nebo [17].");

                                } else {

                                    System.out.println("Napis [10], [11] nebo [16].");

                                }

                                vstup.nextLine();

                            }

                        }

                    } else {

                        System.out.println("Vchazis do zmrzlinarstvi a zjistujes, ze zmrlinu dnes toci znyma bojovnik Honza Cena.");
                        System.out.println("Co udelas?\nJit si dat zmrzlinu[1]\nJit si popovidat s Honzou Cenou[2]");

                        while (true) {

                            try {

                                int volba14 = vstup.nextInt();

                                if (volba14 == 1 || volba14 == 2) {

                                    if (volba14 == 1) {

                                        System.out.println("Davat si zmrzlinu takhle blizko tvemu cili neni zrovna nejchytrejsi a nejlepsi pro tvou celistni linii. Ztracis 4 RIZZY.");

                                        RIZZ -= 4;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        if (cina) {

                                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do McDonalds[10]\nJit do nemocnice[11]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                        } else {

                                            System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do McDonalds[10]\nJit do nemocnice[11]\nJit do kralovstvi Skibidialni toalety[16]");

                                        }

                                        while (true) {

                                            try {

                                                int lokace14 = vstup.nextInt();

                                                if (lokace14 == 10 || lokace14 == 11 || lokace14 == 16 || lokace14 == 17 && cina == true) {

                                                    lokace = lokace14;

                                                    break;

                                                } else {

                                                    if (cina) {

                                                        System.out.println("Napis [10], [11], [16] nebo [17].");

                                                    } else {

                                                        System.out.println("Napis [10], [11] nebo [16].");

                                                    }

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                if (cina) {

                                                    System.out.println("Napis [10], [11], [16] nebo [17].");

                                                } else {

                                                    System.out.println("Napis [10], [11] nebo [16].");

                                                }

                                                vstup.nextLine();

                                            }

                                        }

                                    } else {

                                        System.out.println("Honzo Cenovi prozrazujes, ze si jeho vasnivy fanousek a on se ti omylem prorekne, ze ve zmrzlinarstvi pracuje, aby zvedl povedomi obcanu Ohia o cinske ctrvti a Cine.");
                                        System.out.println("Co udelas?\nExposenout Honzu Cenu na internetu[1]\nNechat to byt[2]");

                                        while (true) {

                                            try {

                                                int volba141 = vstup.nextInt();

                                                if (volba141 == 1 || volba141 == 2) {

                                                    if (volba141 == 1) {

                                                        System.out.println("Exposujes Honzu Cenu na internetu a stavas se tim popularni. Ziskavas 6 RIZZU.");

                                                        RIZZ += 6;

                                                        rizz();

                                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                        if (cina) {

                                                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do McDonalds[10]\nJit do nemocnice[11]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                                        } else {

                                                            System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do McDonalds[10]\nJit do nemocnice[11]\nJit do kralovstvi Skibidialni toalety[16]");

                                                        }

                                                        while (true) {

                                                            try {

                                                                int lokace14 = vstup.nextInt();

                                                                if (lokace14 == 10 || lokace14 == 11 || lokace14 == 16 || lokace14 == 17 && cina == true) {

                                                                    lokace = lokace14;

                                                                    break;

                                                                } else {

                                                                    if (cina) {

                                                                        System.out.println("Napis [10], [11], [16] nebo [17].");

                                                                    } else {

                                                                        System.out.println("Napis [10], [11] nebo [16].");

                                                                    }

                                                                }

                                                            } catch (java.util.InputMismatchException e) {

                                                                if (cina) {

                                                                    System.out.println("Napis [10], [11], [16] nebo [17].");

                                                                } else {

                                                                    System.out.println("Napis [10], [11] nebo [16].");

                                                                }

                                                                vstup.nextLine();

                                                            }

                                                        }

                                                    } else {

                                                        System.out.println("Slibujes Honzovi Cenovi, ze ho neexposenes na internetu a on ti za to dava par looksmaxxing rad. Ziskavas 8 RIZZU.");

                                                        RIZZ += 8;

                                                        rizz();

                                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                        if (cina) {

                                                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do McDonalds[10]\nJit do nemocnice[11]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                                        } else {

                                                            System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do McDonalds[10]\nJit do nemocnice[11]\nJit do kralovstvi Skibidialni toalety[16]");

                                                        }

                                                        while (true) {

                                                            try {

                                                                int lokace14 = vstup.nextInt();

                                                                if (lokace14 == 10 || lokace14 == 11 || lokace14 == 16 || lokace14 == 17 && cina == true) {

                                                                    lokace = lokace14;

                                                                    break;

                                                                } else {

                                                                    if (cina) {

                                                                        System.out.println("Napis [10], [11], [16] nebo [17].");

                                                                    } else {

                                                                        System.out.println("Napis [10], [11] nebo [16].");

                                                                    }

                                                                }

                                                            } catch (java.util.InputMismatchException e) {

                                                                if (cina) {

                                                                    System.out.println("Napis [10], [11], [16] nebo [17].");

                                                                } else {

                                                                    System.out.println("Napis [10], [11] nebo [16].");

                                                                }

                                                                vstup.nextLine();

                                                            }

                                                        }

                                                    }

                                                } else {

                                                    System.out.println("Napis [1] nebo [2].");

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                System.out.println("Napis [1] nebo [2].");

                                                vstup.nextLine();

                                            }

                                        }

                                    }

                                } else {

                                    System.out.println("Napis [1] nebo [2].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }

                        }

                    }

                    break;

                case 15:

                    if (navstiveno[lokace]) {

                        System.out.println("Na prochazce se uz nic zajimaveho nestane.");

                        if (cina) {

                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do nemocnice[11]\nJit k pramenu reky Ohio[12]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                        } else {

                            System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do nemocnice[11]\nJit k pramenu reky Ohio[12]\nJit do kralovstvi Skibidialni toalety[16]");

                        }

                        while (true) {

                            try {

                                int lokace15 = vstup.nextInt();

                                if (lokace15 == 11 || lokace15 == 12 || lokace15 == 16 || lokace15 == 17 && cina == true) {

                                    lokace = lokace15;

                                    break;

                                } else {

                                    if (cina) {

                                        System.out.println("Napis [11], [12], [16] nebo [17].");

                                    } else {

                                        System.out.println("Napis [11], [12] nebo [16].");

                                    }

                                }

                            } catch (java.util.InputMismatchException e) {

                                if (cina) {

                                    System.out.println("Napis [11], [12], [16] nebo [17].");

                                } else {

                                    System.out.println("Napis [11], [12] nebo [16].");

                                }

                                vstup.nextLine();

                            }

                        }

                    } else {

                        System.out.println("Prochazis se po ulici, hledis si sveho a najednou se u tebe objevi znamy influencer MrBeast s jeho stabem a stetcem s cervenou barvou a kolem tebe na zemi maluji kruh.");

                        while (true) {

                            try {

                                System.out.println("Co udelas?\nHledet si sveho a pokracovat v prochazeni[1]\nZustat stat v kruhu[2]");

                                int volba15 = vstup.nextInt();

                                if (volba15 == 1 || volba15 == 2) {

                                    if (volba15 == 1) {

                                        System.out.println("Prekracujes cervenou lajnu a MrBeast ti oznamuje, ze si prohral challenge jmenem \"Zustan v kruhu 24 hodin\".");
                                        System.out.println("Sice si prohral 1 000 000 dollaru, ale internet si o tobe mysli, ze si mysteriozni sigma a po celem tiktoku jsou na tebe edity. Ziskavas 6 RIZZU.");

                                        RIZZ += 6;

                                        rizz();

                                        System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                        if (cina) {

                                            System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do nemocnice[11]\nJit k pramenu reky Ohio[12]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                        } else {

                                            System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do nemocnice[11]\nJit k pramenu reky Ohio\nJit do kralovstvi Skibidialni toalety[16]");

                                        }

                                        while (true) {

                                            try {

                                                int lokace15 = vstup.nextInt();

                                                if (lokace15 == 11 || lokace15 == 12 || lokace15 == 16 || lokace15 == 17 && cina == true) {

                                                    lokace = lokace15;

                                                    break;

                                                } else {

                                                    if (cina) {

                                                        System.out.println("Napis [11], [12], [16] nebo [17].");

                                                    } else {

                                                        System.out.println("Napis [11], [12] nebo [16].");

                                                    }

                                                }

                                            } catch (java.util.InputMismatchException e) {

                                                if (cina) {

                                                    System.out.println("Napis [11], [12], [16] nebo [17].");

                                                } else {

                                                    System.out.println("Napis [11], [12] nebo [16].");

                                                }

                                                vstup.nextLine();

                                            }

                                        }

                                    } else {

                                        kruh += 1;

                                        if (kruh == 24) {

                                            System.out.println("MrBeast ti gratuluje k vyhre 1 000 000 dollaru ve hre jmenem \"Zustan 24 hodin v kruhu\". Stavas se popularnim a za penize si kupujes novy drip a looksmaxxing produkty. Ziskavas 8 RIZZU.");

                                            RIZZ += 8;

                                            rizz();

                                            System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                            if (cina) {

                                                System.out.println("Podival si se do mapy a odsud mas ctyri moznosti:\nJit do nemocnice[11]\nJit k pramenu reky Ohio[12]\nJit do kralovstvi Skibidialni toalety[16]\nRozmyslet si nabidku mistra Wu, vse hodit za hlavu a odletet do Ciny se naucit Spinjitzu a Bankai[17]");

                                            } else {

                                                System.out.println("Podival si se do mapy a odsud mas tri moznosti:\nJit do nemocnice[11]\nJit k pramenu reky Ohio\nJit do kralovstvi Skibidialni toalety[16]");

                                            }

                                            while (true) {

                                                try {

                                                    int lokace15 = vstup.nextInt();

                                                    if (lokace15 == 11 || lokace15 == 12 || lokace15 == 16 || lokace15 == 17 && cina == true) {

                                                        lokace = lokace15;

                                                        break;

                                                    } else {

                                                        if (cina) {

                                                            System.out.println("Napis [11], [12], [16] nebo [17].");

                                                        } else {

                                                            System.out.println("Napis [11], [12] nebo [16].");

                                                        }

                                                    }

                                                } catch (java.util.InputMismatchException e) {

                                                    if (cina) {

                                                        System.out.println("Napis [11], [12], [16] nebo [17].");

                                                    } else {

                                                        System.out.println("Napis [11], [12] nebo [16].");

                                                    }

                                                    vstup.nextLine();

                                                }

                                            }

                                        }

                                    }

                                } else {

                                    System.out.println("Napis [1] nebo [2].");

                                }

                            } catch (java.util.InputMismatchException e) {

                                System.out.println("Napis [1] nebo [2].");

                                vstup.nextLine();

                            }

                        }

                    }

                    break;

                case 16:

                    System.out.println("Po dlouhe a narocne ceste konecne prichazis do kralovstvi Skibidialni toalety, kde by se mela nachazet Livvy Dunne, kterou vezni sigma.");
                    System.out.println("Sigma moc dobre tusil, ze se ukazes, a proto se rozhodl, ze souboj o Livvy Dunne s tebou vyresi rychle primo pred branami kralovstvi Skibidialni toalety, cimz prokazuje jak velka sigma je.");
                    System.out.println("Sigma vsem svym skibidi toaletnim poskokum dava prikaz, aby jen pozorovali a ceka na tvou vyzvu.");
                    System.out.println("Co udelas?\nVyzvat sigmu na MOG BATTLE[1]\nVzdat to[2]");

                    while (true) {

                        try {

                            int volba16 = vstup.nextInt();

                            if (volba16 == 1 || volba16 == 2) {

                                if (volba16 == 1) {

                                    rizz();

                                    System.out.println("Vyzval si sigmu na MOG BATTLE.");

                                    int aura1 = 100;
                                    int aura2 = 200;

                                    rizz();

                                    while (aura1 > 0 && aura2 > 0) {

                                        int damage1 = (int) (random.nextInt(41) * nasobic);

                                        aura2 -= damage1;

                                        System.out.println("Tvuj pohled zasahl sigmu za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nSigma aura: " + aura2);

                                        vstup.nextLine();

                                        if (aura2 <= 0) {

                                            System.out.println("V MOG BATTLU si vyhral");

                                            if (ruki) {

                                                System.out.println("Nestihl si se ani nadechnout a nekdo ti tuka na rameno. Je to ruki bazuki, kteremu se pravdepodobne zalibla myslenka rizznout Livvy Dunne, a proto te svym pohledem vyzyva na MOG BATTLE.");
                                                System.out.println("Jeste pred zacatkem, ale ztracis bonus 10 RIZZU, ktery ti ruki bazuki daval.");

                                                RIZZ -= 10;

                                                rizz();

                                                System.out.println("Tvuj RIZZ je prave na hodnote " + RIZZ + " a tvuj RIZZLVL je urovne " + RIZZLVL + ".");

                                                aura1 = 100;
                                                aura2 = 20;

                                                while (aura1 > 0 && aura2 > 0) {

                                                    int damage2 = random.nextInt(61);

                                                    aura1 -= damage2;

                                                    System.out.println("Pohled rukiho bazukiho te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nRuki bazuki aura: " + aura2);

                                                    vstup.nextLine();

                                                    if (aura1 <= 0) {

                                                        System.out.println("V MOG BATTLU si prohral");

                                                        System.out.println("Ruki bazuki se stava kral kralovstvi Skibidialni toalety, rizzuje Livvy Dunne a ty se do konce dveho zivota propadas do depresi.");
                                                        System.out.println("GAME OVER");

                                                        break;

                                                    }

                                                    damage1 = (int) (random.nextInt(41) * nasobic);

                                                    aura2 -= damage1;

                                                    System.out.println("Tvuj pohled zasahl rukiho bazukiho za " + damage1 + " negativni aury.\nTvoje aura: " + aura1 + "\nRuki bazukiho aura: " + aura2);

                                                    vstup.nextLine();

                                                    if (aura2 <= 0) {

                                                        System.out.println("V MOG BATTLU si vyhral.");
                                                        System.out.println("Totalne zhnuseny zradou sveho nejlepsiho pritele se vydavas za Livvy Dunne mezitim co se ti vsechny skibidi toalety klani.");

                                                        if (RIZZ > 40) {

                                                            System.out.println("Prichazis k Livvy Dunne a jelikoz tvuj rizz je na dostatecne urovni, tak se ti ji dari rizznout.");
                                                            System.out.println("gg");

                                                        } else {

                                                            System.out.println("Prichazis k Livvy Dunne a zjistujes, ze tvuj rizz je na na moc male urovni a ona je mimo tvoji uroven, a proto utika.");
                                                            System.out.println("GAME OVER");

                                                        }

                                                        break;

                                                    }

                                                }
                                                
                                                break;

                                            } else {

                                                System.out.println("Totalne zniceny se vydavas za Livvy Dunne mezitim co se ti vsechny skibidi toalety klani.");

                                                if (RIZZ > 40) {

                                                    System.out.println("Prichazis k Livvy Dunne a jelikoz tvuj rizz je na dostatecne urovni, tak se ti ji dari rizznout.");
                                                    System.out.println("gg");

                                                } else {

                                                    System.out.println("Prichazis k Livvy Dunne a zjistujes, ze tvuj rizz je na na moc male urovni a ona je mimo tvoji uroven, a proto utika.");
                                                    System.out.println("GAME OVER");

                                                }

                                                break;

                                            }

                                        }

                                        int damage2 = random.nextInt(41);

                                        aura1 -= damage2;

                                        System.out.println("Pohled sigmy te zasahl za " + damage2 + " negativni aury.\nTvoje aura: " + aura1 + "\nSigma aura: " + aura2);

                                        vstup.nextLine();

                                        if (aura1 <= 0) {

                                            System.out.println("V MOG BATTLU si prohral.");

                                            System.out.println("Sigma vyhrava MOG BATTLE a tim si zajistuje cele kralovstvi Skibidialni toalety a Livvy Dunne. Ty se propadas hanbou a do konce sveho zivota se utapis do depresi.");
                                            System.out.println("GAME OVER");

                                            break;

                                        }

                                    }
                                    
                                    break;

                                } else {

                                    System.out.println("Vzdat se je tva nejvetsi chyba v zivote. Propadas se hanbou a do konce sveho se utapis do depresi.");
                                    System.out.println("GAME OVER");
                                    
                                    break;

                                }

                            } else {

                                System.out.println("Napis [1] nebo [2].");

                            }

                        } catch (java.util.InputMismatchException e) {

                            System.out.println("Napis [1] nebo [2].");

                            vstup.nextLine();

                        }

                    }
                    
                    cina = true;

                    break;

                case 17:

                    System.out.println("Odletas s  mistrem Wu do Ciny, kde se ucis Spinjitzu a Bankai. Tve vnitrni chakry se dostavaji na uroven klidu a pohody. Prichazis na smysl zivota a svuj dlouhy a pohodovy zivot dozivas v Cine.");
                    System.out.println("gg");

                    cina = true;

                    break;

            }

            if (cina) {

                break;

            }

        }

    }

}